from example4 import *
from events import *
from network import *
import network

from twisted.spread import pb

#------------------------------------------------------------------------------
class TimerController:
	"""A controller that sends of an event every second"""
	def __init__(self, evManager, reactor):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

		self.reactor = reactor
		self.numClients = 0

	#-----------------------------------------------------------------------
	def NotifyApplicationStarted( self ):
		self.reactor.callLater( 1, self.Tick )

	#-----------------------------------------------------------------------
	def Tick(self):
		if self.numClients == 0:
			return

		ev = SecondEvent()
		self.evManager.Notify( ev )
		self.reactor.callLater( 1, self.Tick )

	#----------------------------------------------------------------------
	def Notify(self, event):
		if isinstance( event, ClientConnectEvent ):
			self.numClients += 1
			if self.numClients == 1:
				self.Tick()
		if isinstance( event, ClientDisconnectEvent ):
			self.numClients -= 1

#------------------------------------------------------------------------------
class NetworkClientController(pb.Root):
	"""We RECEIVE events from the CLIENT through this object"""
	def __init__(self, evManager, sharedObjectRegistry):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

		self.sharedObjs = sharedObjectRegistry

		self.playerPasswords = {}

		#this is needed for GetEntireState()
		self.game = None

	#----------------------------------------------------------------------
	def remote_ClientConnect(self, netClient):
		#print "CLIENT CONNECT"
		ev = ClientConnectEvent( netClient )
		self.evManager.Notify( ev )
		return 1

	#----------------------------------------------------------------------
	def remote_GetGame(self):
		"""this is usually called when a client first connects or
		when they had dropped and reconnect"""
		if self.game == None:
			return [0,0]
		gameID = id( self.game )
		gameDict = self.game.getStateToCopy( self.sharedObjs )

		print "returning: ", gameID
		return [gameID, gameDict]
	
	#----------------------------------------------------------------------
	def remote_GetObjectState(self, objectID):
		#print "request for object state", objectID
		if not self.sharedObjs.has_key( objectID ):
			print "No key on the server"
			return [0,0]
		object = self.sharedObjs[objectID]
		objDict = object.getStateToCopy( self.sharedObjs )

		return [objectID, objDict]
	
	#----------------------------------------------------------------------
	def remote_ClientEvent(self, event):
		ev = event
		if isinstance(event, CopyableCharactorPlaceRequest ):
			print "reformatting..."
			player = self.sharedObjs[event.playerID]
			charactor = self.sharedObjs[event.charactorID]
			sector = self.sharedObjs[event.sectorID]
			ev = CharactorPlaceRequest( player, charactor, sector )
		elif isinstance(event, CopyableCharactorMoveRequest ):
			print "reformatting..."
			player = self.sharedObjs[event.playerID]
			charactor = self.sharedObjs[event.charactorID]
			direction = event.direction
			ev = CharactorMoveRequest(player, charactor, direction)
		else:
			ev = event

		self.evManager.Notify( ev )

		return 1

	#----------------------------------------------------------------------
	def Notify(self, event):
		if isinstance( event, GameStartedEvent ):
			self.game = event.game


#------------------------------------------------------------------------------
class NetworkClientView:
	"""We SEND events to the CLIENT through this object"""
	def __init__(self, evManager, sharedObjectRegistry):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

		self.clients = []
		self.sharedObjs = sharedObjectRegistry
		#TODO:
		#every 5 seconds, the server should poll the clients to see if
		# they're still connected
		self.pollSeconds = 0


	#----------------------------------------------------------------------
 	def Pong(self ):
		pass
	#----------------------------------------------------------------------
 	def RemoteCallError(self, failure, client):
		from twisted.internet.error import ConnectionLost
		#trap ensures that the rest will happen only 
		#if the failure was ConnectionLost
		failure.trap(ConnectionLost)
		self.DisconnectClient(client)
		return failure

	#----------------------------------------------------------------------
	def DisconnectClient(self, client):
		print "Disconnecting Client", client
		self.clients.remove( client )
		ev = ClientDisconnectEvent( client ) #client id in here
		self.evManager.Notify( ev )

	#----------------------------------------------------------------------
	def RemoteCall( self, client, fnName, *args):
		from twisted.spread.pb import DeadReferenceError

		try:
			remoteCall = client.callRemote(fnName, *args)
			#remoteCall.addCallback( self.Pong )
			remoteCall.addErrback( self.RemoteCallError, client )
		except DeadReferenceError:
			self.DisconnectClient(client)


	#----------------------------------------------------------------------
 	def Notify(self, event):

		if isinstance( event, ClientConnectEvent ):
			self.clients.append( event.client )
			#TODO tell the client what it's ID is

		if isinstance( event, SecondEvent ):
			self.pollSeconds +=1
			if self.pollSeconds == 10:
				self.pollSeconds = 0
				for client in self.clients:
					self.RemoteCall( client, "Ping" )


		ev = event

		#don't broadcast events that aren't Copyable
		if not isinstance( ev, pb.Copyable ):
			evName = ev.__class__.__name__
			if not hasattr( network, "Copyable"+evName):
				return
			copyableClass = getattr( network, "Copyable"+evName)
			if copyableClass not in serverToClientEvents:
				return
			ev = copyableClass( ev, self.sharedObjs )

		elif ev.__class__ not in serverToClientEvents:
			#print "SERVER NOT SENDING: " +str(ev)
			return 

		#NOTE: this is very "chatty".  We could restrict 
		#      the number of clients notified in the future
		for client in self.clients:
			print "==============server===sending: ", str(ev)
			self.RemoteCall( client, "ServerEvent", ev )


#------------------------------------------------------------------------------
class TextLogView:
	"""..."""
	def __init__(self, evManager):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

	#----------------------------------------------------------------------
 	def Notify(self, event):

		if isinstance( event, CharactorPlaceEvent ):
			print event.name, " at ", event.charactor.sector

		elif isinstance( event, CharactorMoveEvent ):
			print event.name, " to ", event.charactor.sector

		elif not isinstance( event, TickEvent ):
			print event.name

		
#from twisted.internet.app import ApplicationService
#------------------------------------------------------------------------------
#class StartTrigger( ApplicationService ):
	#def __init__(self, application, timerController ):
		#ApplicationService.__init__(self, "sTrigger", application)
		#self.timerController = timerController

	#-----------------------------------------------------------------------
	#def startService( self ):
		#self.timerController.NotifyApplicationStarted()


#------------------------------------------------------------------------------
def main():
	"""..."""
	from twisted.internet.app import Application
	from twisted.internet import reactor

	evManager = EventManager()
	sharedObjectRegistry = {}

	log = TextLogView( evManager )
	timer = TimerController( evManager, reactor )
	clientContr = NetworkClientController( evManager, sharedObjectRegistry )
	clientView = NetworkClientView( evManager, sharedObjectRegistry )
	game = Game( evManager )
	
	#from twisted.spread.jelly import globalSecurity
	#globalSecurity.allowModules( network )

	application = Application("myServer")
	application.listenTCP(8000, pb.BrokerFactory(clientContr) )

	#startTrigger = StartTrigger( application, timer )

	application.run()

if __name__ == "__main__":
	main()
