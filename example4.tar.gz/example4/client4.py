from events import *
from example4 import *
from network import *
import network

from twisted.spread import pb

#------------------------------------------------------------------------------
class NetworkServerView(pb.Root):
	"""We SEND events to the server through this object"""
	STATE_PREPARING = 0
	STATE_CONNECTING = 1
	STATE_CONNECTED = 2

	#----------------------------------------------------------------------
	def __init__(self, evManager, sharedObjectRegistry):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

		self.state = NetworkServerView.STATE_PREPARING
		self.server = None

		self.sharedObjs = sharedObjectRegistry

	#----------------------------------------------------------------------
	def Connected(self, server):
		print "CONNECTED"
		self.server = server
		self.state = NetworkServerView.STATE_CONNECTED
		ev = ServerConnectEvent( server )
		self.evManager.Notify( ev )

	#----------------------------------------------------------------------
	def ConnectFailed(self, server):
		self.state = NetworkServerView.STATE_PREPARING
		print "CONNECTION FAILED"

	#----------------------------------------------------------------------
	def Notify(self, event):
		ev = event

		if isinstance( event, TickEvent ) \
		   and self.state == NetworkServerView.STATE_PREPARING:
			self.state = NetworkServerView.STATE_CONNECTING
			remoteResponse = pb.getObjectAt("localhost", 8000, 30)
			remoteResponse.addCallback(self.Connected )
			#errback                  #self.ConnectFailed)

		#see if it's Copyable.  If not, see if there's a Copyable 
		#replacement for it.  If not, just ignore it.
		if not isinstance( event, pb.Copyable):
			evName = event.__class__.__name__
			if not hasattr( network, "Copyable" + evName ):
				return
			copyableClass = getattr( network, "Copyable" + evName )
			if copyableClass not in clientToServerEvents:
				return
			ev = copyableClass( event, self.sharedObjs )

		elif ev.__class__ not in clientToServerEvents:
			#print "CLIENT NOT SENDING: " +str(ev)
			return 
			
		#print "    ====   Client sending ===  ", str(ev)
		remoteCall = self.server.callRemote("ClientEvent",ev) 




#------------------------------------------------------------------------------
class NetworkServerController(pb.Referenceable):
	"""We RECEIVE events from the server through this object"""
	def __init__(self, evManager, twistedReactor):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

		self.reactor = twistedReactor

	#----------------------------------------------------------------------
	def remote_ServerEvent(self, event):
		#print "=================GOT AN EVENT FROM SERVER:", str(event)
		self.evManager.Notify( event )
		return 1

	#----------------------------------------------------------------------
	def remote_Ping(self):
		pong = 1
		return pong

	#----------------------------------------------------------------------
	def Notify(self, event):
		if isinstance( event, ServerConnectEvent ):
			#tell the server that we're listening to it and
			#it can access this object
			remoteResponse = event.server.callRemote("ClientConnect", self)
		if isinstance( event, TickEvent ):
			#print "PUMPING NETWORK"
			self.reactor.iterate()


#------------------------------------------------------------------------------
class PhonyEventManager(EventManager):
	"""this object is responsible for coordinating most communication
	between the Model, View, and Controller."""
	#----------------------------------------------------------------------
	def Notify( self, event ):
		pass

#------------------------------------------------------------------------------
class PhonyModel:
	"""..."""
	#----------------------------------------------------------------------
	def __init__(self, evManager, sharedObjectRegistry):
		self.sharedObjs = sharedObjectRegistry
		self.game = None
		self.server = None
		self.phonyEvManager = PhonyEventManager()
		self.realEvManager = evManager
		self.neededObjects = [] 
		self.waitingObjectStack = []

		self.realEvManager.RegisterListener( self )

	#----------------------------------------------------------------------
 	def GameReturned(self, response):
		if response[0] == 0:
			print "GameReturned : game HASNT started"
			#the game has not been started on the server.
			#we'll be informed of the gameID when we receive the
			#GameStartedEvent
			return None
		else:
			gameID = response[0]
			print "GameReturned : game started ", gameID

			self.sharedObjs[gameID] = self.game
		return self.ObjStateReturned( response, self.GameSyncCallback )

	#----------------------------------------------------------------------
 	def ObjStateReturned(self, response, nextFn=None):
		"""this is a callback that is called in response to 
		invoking GetObjectState on the server"""

		print "looking for ", response
		if response[0] == 0:
			print "GOT ZERO -- better error handler here"
			return None
		objID = response[0]
		objDict = response[1]
		obj = self.sharedObjs[objID]

		retval = obj.setCopyableState(objDict, self.sharedObjs)
		if retval[0] == 1:
			if objID in self.neededObjects:
				self.neededObjects.remove(objID)

		else:
			for neededObjID in retval[1]:
				if neededObjID not in self.neededObjects:
					self.neededObjects.append(neededObjID)
			print "failed.  still need ", self.neededObjects
	
		self.waitingObjectStack.append( (obj, objDict, nextFn) )

		self.GetAllNeededObjects()
	
	#----------------------------------------------------------------------
 	def GetAllNeededObjects(self):
		if len(self.neededObjects) == 0:
			while self.waitingObjectStack:
				t = self.waitingObjectStack.pop()
				obj = t[0]
				objDict = t[1]
				fn = t[2]
				retval = obj.setCopyableState(objDict, self.sharedObjs)
				if retval[0] == 0:
					print "WEIRD!!!!!!!!!!!!!!!!!!"

				print "fn is ", fn
				if fn:
					fn( obj )
			return

		#grap a random object ID from the Set
		nextID = self.neededObjects[len(self.neededObjects)-1]
		print "next one to grab: ", nextID
		remoteResponse = self.server.callRemote("GetObjectState", nextID)
		remoteResponse.addCallback(self.ObjStateReturned)
		
	#----------------------------------------------------------------------
 	def Notify(self, event):
		if isinstance( event, ServerConnectEvent ):
			self.server = event.server
			#when we connect to the server, we should get the
			#entire game state.  this also applies to RE-connecting
			if not self.game:
				self.game = Game( self.phonyEvManager )
			remoteResponse = self.server.callRemote("GetGame")
			remoteResponse.addCallback(self.GameReturned)

		elif isinstance( event, CopyableGameStartedEvent ):
			gameID = event.gameID
			if not self.game:
				self.game = Game( self.phonyEvManager )
			self.sharedObjs[gameID] = self.game
			ev = GameStartedEvent( self.game )
			self.realEvManager.Notify( ev )

		if isinstance( event, CopyableMapBuiltEvent ):
			mapID = event.mapID
			if self.sharedObjs.has_key(mapID):
				map = self.sharedObjs[mapID]
				self.MapBuiltCallback( map )
			else:
				map = self.game.map
				self.sharedObjs[mapID] = map
				remoteResponse = self.server.callRemote("GetObjectState", mapID)
				remoteResponse.addCallback(self.ObjStateReturned , self.MapBuiltCallback)

		if isinstance( event, CopyablePlayerJoinEvent ):
			playerID = event.playerID
			if self.sharedObjs.has_key(playerID):
				player = self.sharedObjs[playerID]
				self.PlayerJoinCallback( player )
			else:
				player = Player( self.phonyEvManager )
				self.sharedObjs[playerID] = player
				remoteResponse = self.server.callRemote("GetObjectState", playerID)
				remoteResponse.addCallback(self.ObjStateReturned, self.PlayerJoinCallback)

		if isinstance( event, CopyableCharactorPlaceEvent ):
			charactorID = event.charactorID
			if not self.sharedObjs.has_key(charactorID):
				print "Something really wrong.  perhaps sync"
				return
			else:
				charactor = self.sharedObjs[charactorID]
				remoteResponse = self.server.callRemote("GetObjectState", charactorID)
				remoteResponse.addCallback(self.ObjStateReturned, self.CharactorPlaceCallback)

		if isinstance( event, CopyableCharactorMoveEvent ):
			charactorID = event.charactorID
			if self.sharedObjs.has_key(charactorID):
				charactor = self.sharedObjs[charactorID]
				self.CharactorMoveCallback( charactor )
			else:
				charactor = self.game.players[0].charactors[0]
				self.sharedObjs[charactorID] = charactor
			remoteResponse = self.server.callRemote("GetObjectState", charactorID)
			remoteResponse.addCallback(self.ObjStateReturned, self.CharactorMoveCallback)

	#----------------------------------------------------------------------
 	def CharactorPlaceCallback(self, charactor):
		ev = CharactorPlaceEvent( charactor )
		self.realEvManager.Notify( ev )
	#----------------------------------------------------------------------
 	def MapBuiltCallback(self, map):
		ev = MapBuiltEvent( map )
		self.realEvManager.Notify( ev )
	#----------------------------------------------------------------------
 	def GameSyncCallback(self, game):
		print "sending out the GS EVENT------------------==========="
		ev = GameSyncEvent( game )
		self.realEvManager.Notify( ev )
	#----------------------------------------------------------------------
 	def CharactorMoveCallback(self, charactor):
		ev = CharactorMoveEvent( charactor )
		self.realEvManager.Notify( ev )
	#----------------------------------------------------------------------
 	def PlayerJoinCallback(self, player):
		self.game.AddPlayer( player )
		ev = PlayerJoinEvent( player )
		self.realEvManager.Notify( ev )


#------------------------------------------------------------------------------
def main():
	"""..."""
	evManager = EventManager()
	sharedObjectRegistry = {}

	#import random
	#rng = random.Random()
	#playerName = str( rng.randrange(1,100) )
	#player = Player( evManager )

	keybd = KeyboardController( evManager )
	spinner = CPUSpinnerController( evManager )
	pygameView = PygameView( evManager )

	phonyModel = PhonyModel( evManager, sharedObjectRegistry  )

	#from twisted.spread.jelly import globalSecurity
	#globalSecurity.allowModules( network )

	from twisted.internet import reactor
	serverController = NetworkServerController( evManager, reactor )
	serverView = NetworkServerView( evManager, sharedObjectRegistry )
	
	spinner.Run()

if __name__ == "__main__":
	main()
