
playerData = {
	'name': 'dude',
	'charactorName': 'Barney Jr',
}

dialogSize = (300,200)
