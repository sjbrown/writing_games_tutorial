#! /usr/bin/env python
'''
Example server
'''

from twisted.spread import pb
from twisted.spread.pb import DeadReferenceError
from twisted.cred import checkers, portal
from zope.interface import implements
from example1 import EventManager, Game
from events import *
import network

#------------------------------------------------------------------------------
class NoTickEventManager(EventManager):
	'''This subclass of EventManager doesn't wait for a Tick event before
	it starts consuming its event queue.  The server module doesn't have
	a CPUSpinnerController, so Ticks will not get generated.
	'''
	def __init__(self):
		EventManager.__init__(self)
		self._lock = False
	def Post(self, event):
		self.eventQueue.append(event)
		print 'ev q is', self.eventQueue, 'lock is', self._lock
		if not self._lock:
			self._lock = True
			print 'consuming queue'
			self.ActuallyUpdateListeners()
			self.ConsumeEventQueue()
			self._lock = False



#------------------------------------------------------------------------------
class TimerController:
	"""A controller that sends of an event every second"""
	def __init__(self, evManager, reactor):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

		self.reactor = reactor
		self.numClients = 0

	#-----------------------------------------------------------------------
	def NotifyApplicationStarted( self ):
		self.reactor.callLater( 1, self.Tick )

	#-----------------------------------------------------------------------
	def Tick(self):
		if self.numClients == 0:
			return

		ev = SecondEvent()
		self.evManager.Post( ev )
		ev = TickEvent()
		self.evManager.Post( ev )
		self.reactor.callLater( 1, self.Tick )

	#----------------------------------------------------------------------
	def Notify(self, event):
		if isinstance( event, ClientConnectEvent ):
			# first client connected.  start the clock.
			self.numClients += 1
			if self.numClients == 1:
				self.Tick()
		if isinstance( event, ClientDisconnectEvent ):
			print 'got client part.  reducing self.numclients'
			self.numClients -= 1
			print 'self.numclients', self.numClients
		if isinstance( event, FatalEvent ):
			PostMortem(event, self.reactor)

#------------------------------------------------------------------------------
def PostMortem(fatalEvent, reactor):
    print "\n\nFATAL EVENT.  STOPPING REACTOR"
    reactor.stop()
    from pprint import pprint
    print 'Shared Objects at the time of the fatal event:'
    pprint( _sharedObjectRegistry )

#------------------------------------------------------------------------------
class MyRealm:
	implements(portal.IRealm)
	def __init__(self, evManager, sharedObjectRegistry):
		self.evManager = evManager
		self.sharedObjs = sharedObjectRegistry

		# maps avatars to player(s) they control
		self.playersControlledByAvatar = {}

	def requestAvatar(self, avatarID, mind, *interfaces):
		#NOTE mind will be the client's controller, which will be a NetworkClientView from this end
		print ' v'*30
		print 'requesting avatar id: ', avatarID
		print ' ^'*30
		if pb.IPerspective not in interfaces:
			print 'TWISTED FAILURE'
			raise NotImplementedError
		# this should be ok even when avatarID is checkers.ANONYMOUS
		self.playersControlledByAvatar[avatarID] = []
		controller = NetworkClientController(self.evManager,
		                                     self.sharedObjs,
		                                     avatarID,
		                                     self)
		return pb.IPerspective, controller, controller.clientDisconnect

	def knownPlayers(self):
		allPlayers = []
		for pList in self.playersControlledByAvatar.values():
			allPlayers.extend(pList)
		return allPlayers


#------------------------------------------------------------------------------
class NetworkClientController(pb.Avatar):
	"""We RECEIVE events from the CLIENT through this object
	There is an instance of NetworkClientController for each connected
	client.
	"""
	def __init__(self, evManager, sharedObjectRegistry, avatarID, realm):
		self.evManager = evManager
		self.evManager.RegisterListener( self )
		self.sharedObjs = sharedObjectRegistry
		self.avatarID = avatarID
		self.realm = realm

		# this is needed for GetEntireState()
		self.game = None

	#----------------------------------------------------------------------
	def clientDisconnect(self):
		'''When a client disconnect is detected, this method
		gets called
		'''
		ev = ClientDisconnectEvent( self.avatarID )
		self.evManager.Post( ev )

	#----------------------------------------------------------------------
	def perspective_ClientConnect(self, netClient):
		print "\nremote_CLIENT CONNECT"
		ev = ClientConnectEvent( netClient, self.avatarID )
		self.evManager.Post( ev )
		if self.game == None:
			gameID = 0
		else:
			gameID = id(self.game)
		return gameID

	#----------------------------------------------------------------------
	def perspective_GetGame(self):
		"""this is usually called when a client first connects or
		when they had dropped and reconnect"""
		if self.game == None:
			return [0,0]
		gameID = id( self.game )
		gameDict = self.game.getStateToCopy( self.sharedObjs )

		print "returning: ", gameID
		return [gameID, gameDict]
	
	#----------------------------------------------------------------------
	def perspective_GetObjectState(self, objectID):
		#print "request for object state", objectID
		if not self.sharedObjs.has_key( objectID ):
			print "No key on the server"
			return [0,0]
		obj = self.sharedObjs[objectID]
		objDict = obj.getStateToCopy( self.sharedObjs )

		return [objectID, objDict]
	
	#----------------------------------------------------------------------
	def perspective_EventOverNetwork(self, event):
		if isinstance(event, network.CopyableCharactorPlaceRequest):
			try:
			    player = self.sharedObjs[event.playerID]
			except KeyError, ex:
			    self.evManager.Post( FatalEvent( ex ) )
			    raise
			pName = player.name
			if pName not in self.PlayersIControl():
			    print 'i do not control', pName
			    print 'see?', self.PlayersIControl()
			    print 'so i will ignore', event
			    return
			try:
			    charactor = self.sharedObjs[event.charactorID]
			    sector = self.sharedObjs[event.sectorID]
			except KeyError, ex:
			    self.evManager.Post( FatalEvent( ex ) )
			    raise
			ev = CharactorPlaceRequest( player, charactor, sector )
		elif isinstance(event, network.CopyableCharactorMoveRequest):
			try:
			    player = self.sharedObjs[event.playerID]
			except KeyError, ex:
			    self.evManager.Post( FatalEvent( ex ) )
			    raise
			pName = player.name
			if pName not in self.PlayersIControl():
			    return
			try:
			    charactor = self.sharedObjs[event.charactorID]
			except KeyError, ex:
			    print 'sharedObjs did not have key:', ex
			    print 'current sharedObjs:', self.sharedObjs
			    print 'Did a client try to poison me?'
			    self.evManager.Post( FatalEvent( ex ) )
			    raise
			direction = event.direction
			ev = CharactorMoveRequest(player, charactor, direction)
		elif isinstance(event, PlayerJoinRequest):
			pName = event.playerDict['name']
			if pName in self.realm.knownPlayers():
			    print 'this player has already joined'
			    return
			self.ControlPlayer(pName)
			ev = event
		else:
			ev = event

		self.evManager.Post( ev )

		return 1

	#----------------------------------------------------------------------
	def Notify(self, event):
		if isinstance( event, GameStartedEvent ):
			self.game = event.game

	#----------------------------------------------------------------------
	def PlayersIControl(self):
		return self.realm.playersControlledByAvatar[self.avatarID]

	#----------------------------------------------------------------------
	def ControlPlayer(self, playerName):
		players = self.PlayersIControl()
		players.append(playerName)
		

#------------------------------------------------------------------------------
class TextLogView(object):
	def __init__(self, evManager):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

	#----------------------------------------------------------------------
	def Notify(self, event):
		if isinstance( event, TickEvent ):
			return

		print 'TEXTLOG <',
		
		if isinstance( event, CharactorPlaceEvent ):
			print event.name, " at ", event.charactor.sector

		elif isinstance( event, CharactorMoveEvent ):
			print event.name, " to ", event.charactor.sector
		else:
			print 'event:', event


#------------------------------------------------------------------------------
class NetworkClientView(object):
	"""We SEND events to the CLIENT through this object"""
	def __init__(self, evManager, sharedObjectRegistry):
		self.evManager = evManager
		self.evManager.RegisterListener( self )

		self.clients = {}
		self.sharedObjs = sharedObjectRegistry
		#TODO:
		#every 5 seconds, the server should poll the clients to see if
		# they're still connected
		self.pollSeconds = 0

	#----------------------------------------------------------------------
	def RemoteCallError(self, failure, client):
		from twisted.internet.error import ConnectionLost
		#trap ensures that the rest will happen only 
		#if the failure was ConnectionLost
		failure.trap(ConnectionLost)
		self.HandleFailure(client)
		return failure

	#----------------------------------------------------------------------
	def HandleFailure(self, client):
		print "Failing Client", client

	#----------------------------------------------------------------------
	def RemoteCall( self, client, fnName, *args):
		try:
			remoteCall = client.callRemote(fnName, *args)
			remoteCall.addErrback( self.RemoteCallError, client )
		except DeadReferenceError:
			self.HandleFailure(client)


	#----------------------------------------------------------------------
	def Notify(self, event):
		if isinstance( event, ClientConnectEvent ):
			print "\nADDING CLIENT", event.client
			self.clients[event.avatarID] = event.client
		elif isinstance( event, ClientDisconnectEvent ):
			del self.clients[event.avatarID]

		ev = event

		#don't broadcast events that aren't Copyable
		if not isinstance( ev, pb.Copyable ):
			evName = ev.__class__.__name__
			copyableClsName = "Copyable"+evName
			if not hasattr( network, copyableClsName ):
				return
			copyableClass = getattr( network, copyableClsName )
			ev = copyableClass( ev, self.sharedObjs )

		if ev.__class__ not in network.serverToClientEvents:
			print "SERVER NOT SENDING: " +str(ev)
			return

		#NOTE: this is very "chatty".  We could restrict 
		#      the number of clients notified in the future
		if not self.clients:
			print '\n========= STILL NO CLIENTS'
		for avatarID, client in self.clients.items():
			print "\n====server===sending: ", str(ev), 'to',
			print avatarID, '(', client, ')'
			self.RemoteCall( client, "ServerEvent", ev )



_evManager = None
_sharedObjectRegistry = None
#------------------------------------------------------------------------------
def main():
	global _evManager, _sharedObjectRegistry
	from twisted.internet import reactor
	evManager = NoTickEventManager()
	sharedObjectRegistry = {}
	_evManager = evManager
	_sharedObjectRegistry = sharedObjectRegistry

	log = TextLogView( evManager )
	timer = TimerController( evManager, reactor )
	#clientController = NetworkClientController( evManager, sharedObjectRegistry )
	clientView = NetworkClientView( evManager, sharedObjectRegistry )
	game = Game( evManager )

	#factory = pb.PBServerFactory(clientController)
	#reactor.listenTCP( 8000, factory )

	realm = MyRealm(evManager, sharedObjectRegistry)
	portl = portal.Portal(realm)
	checker = checkers.InMemoryUsernamePasswordDatabaseDontUse(
	                                                       user1='pass1',
	                                                       user2='pass1')
	portl.registerChecker(checker)
	reactor.listenTCP(8000, pb.PBServerFactory(portl))

	reactor.run()

if __name__ == "__main__":
	main()
